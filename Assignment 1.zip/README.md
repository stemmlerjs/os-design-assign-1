### Assignment 1
Author: Khalil Stemmler

Hello!

Each part of the Assignment is contained in it's respective folder. Each folder contains:
- the C code
- an output.txt file demonstrating proof of functionality

Cheers.

